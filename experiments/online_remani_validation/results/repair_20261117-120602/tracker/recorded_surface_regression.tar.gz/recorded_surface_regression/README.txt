Recorded planar surface regression, 2026-11-17
Runtime baseline source commit f9e0827c72a433ae714e4d238381442f0d3d695c.
The three point sets were exported from exact geometry+TF+PCD replay. The original model rejected all three. Baseline replay matched all 4836 source frames and six tracker metrics exactly.
Candidate changes only two squared-distance calculations to XY, matching the existing planar motion history/translation. All XYZ surface/collision points are retained. Tolerance0.05m, 4x improvement, bidirectionality and all preconditions are unchanged.
Run ./run.sh on a machine with C++14/Eigen3/gtest. It builds one TU including core implementation, original38 tests and7 recorded/boundary tests, using only relative paths. No ROS master needed. 45/45 passed on aarch64.
This test TU is an experiment artifact, not a new installed framework/CMake target. See selected_surfaces.jsonl for full exact endpoints and selected_surface_analysis.json for measured original/XY distances.
Offline success does not establish live-robot avoidance, person identity or continuous tracking. Full node replay retained a0.4s reacquisition gap near source1794883389.8.
