#!/bin/sh
set -eu
cd "$(dirname "$0")"
ulimit -v 1048576
mkdir -p build
nice -n 15 g++ --param ggc-min-expand=5 --param ggc-min-heapsize=16384 -std=c++14 -O2 -g0 -pthread -Iinclude -I/usr/include/eigen3 test/test_recorded_planar_surface.cpp -lgtest -lgtest_main -o build/test_recorded_planar_surface
./build/test_recorded_planar_surface --gtest_output=xml:build/gtest.xml
